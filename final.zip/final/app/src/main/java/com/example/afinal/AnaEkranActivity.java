package com.example.afinal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AnaEkranActivity extends AppCompatActivity {

    private ImageView menu;
    private ImageView profil;
    private TextView adsoyad;
    private Button addlabel;
    private Button addphoto;
    private Button galery;
    private Button about;
    private Button cikis;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anaekran);

        menu = findViewById(R.id.menu);
        profil = findViewById(R.id.profil);
        adsoyad = findViewById(R.id.adsoyad);
        addlabel = findViewById(R.id.addlabel);
        addphoto = findViewById(R.id.addphoto);
        galery = findViewById(R.id.galery);
        about = findViewById(R.id.about);
        cikis = findViewById(R.id.cikis);

        cikis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnaEkranActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        addlabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnaEkranActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        addphoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnaEkranActivity.this, AddPhotoActivity.class);
                startActivity(intent);
            }
        });
        galery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnaEkranActivity.this, GaleryActivity.class);
                startActivity(intent);
            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnaEkranActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });


    }
}
