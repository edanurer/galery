package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LogInActivity extends AppCompatActivity {
    private TextView label;
    private EditText email;
    private EditText sifre;
    private Button logIn2;
    private TextView or;
    private Button signUp2;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        label = findViewById(R.id.label);
        email = findViewById(R.id.email);
        sifre = findViewById(R.id.sifre);
        logIn2 = findViewById(R.id.logIn2);
        or = findViewById(R.id.or);
        signUp2 = findViewById(R.id.signup2);

        logIn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LogInActivity.this, AnaEkranActivity.class);
                startActivity(intent);
            }
        });
        signUp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LogInActivity.this, signUpActivity.class);
                startActivity(intent);
            }
        });


    }


}
