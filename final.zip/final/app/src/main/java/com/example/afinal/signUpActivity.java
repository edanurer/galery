package com.example.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class signUpActivity extends AppCompatActivity {

    private TextView label2;
    private EditText isim;
    private EditText soyisim;
    private  EditText emailadres;
    private  EditText password;
    private TextView or2;
    private Button kayit;
    private Button girisekran;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        label2 = findViewById(R.id.label2);
        isim = findViewById(R.id.fname);
        soyisim = findViewById(R.id.lname);
        emailadres = findViewById(R.id.emailaddress);
        password = findViewById(R.id.password);
        or2 = findViewById(R.id.or2);
        kayit = findViewById(R.id.giris);
        girisekran = findViewById(R.id.girisekran);

        kayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(signUpActivity.this, AnaEkranActivity.class);
                startActivity(intent);
            }
        });
        girisekran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(signUpActivity.this, LogInActivity.class);
                startActivity(intent);
            }
        });


    }
}
