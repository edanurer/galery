package com.example.afinal;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AddPhotoActivity extends AppCompatActivity {

    private ImageView menup;
    private TextView labelphoto;
    private ImageView resimyukle;
    private ImageView begen1;
    private ImageView begen2;
    private TextView  baslik1;
    private TextView  baslik2;
    private CheckBox check1;
    private CheckBox check2;
    private Button camera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addphoto);

        menup = findViewById(R.id.menup);
        labelphoto = findViewById(R.id.labelphoto);
        resimyukle = findViewById(R.id.resimyukle);
        baslik1 = findViewById(R.id.baslik1);
        begen1 = findViewById(R.id.begen1);
        check1 = findViewById(R.id.check1);
        camera = findViewById(R.id.camera);
    }
}
